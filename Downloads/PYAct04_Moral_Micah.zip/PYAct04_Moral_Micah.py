Item = dict()

isFinish = False
            
while not isFinish:
    name = input("Enter 1 to Add Item, 2 to Exit or 3 to Delete item \n")
    if name == '1':
        addItem = input("Add Item:")
        addAmount = int (input("Add Amount:")) 
        
        Item[addItem] = addAmount
        continue
    elif name == '2':
        name2 = input("Press 4 to View list or 5 to Search \n")
        if name2 == '4':
            print(Item)

        elif name2 == '5':
            search = input("Name to Search: ")
            if search in Item:
                print("Item is in the List")
            else:
                print("Not Existing")
        else:
            print("Invalid Input")
            continue
    elif name == '3':
        delete = input("Item to Delete: \n")

        print("Successfully Deleted!!")

        del Item[delete]
        continue
    elif name == '6':
        print(Item)
        total = sum([i for i in Item.values()])
        print (total,' pesos')
        file = open('Item.txt', 'w')
        file.write('Item in the List\n')
        file.write( str(Item))
        file.write('\nThe total is :\n')
        file.write( str(total))
        file.close()
        isFinish = True
    else:
        print("Invalid Input!!!")
        break
    
