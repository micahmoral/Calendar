
c = {}

def start():
    print("SHOP LiST <3")
    item = input("item :  ")
    amnt = float(input("amount: "))
    c[item] = amnt
    print(c)
    answer = input("add another [a] or [x]")
    if (answer == "a"):
        start()
    else:
        again()

def again():
    ask = input("[s] search or [d] to delete Exit(AnyButton)")
    if (ask == "s"):
        ask = input("enter the key you are searching for:")
        print(ask, "is in the",c[ask])
        again()
    
    elif(ask== "d"):
        ask = input("enter the key you want to delete?")
        del c[ask]
        print(c)
        again()
    else:
        print(c)
        print("Goodbye ! ")

start()
