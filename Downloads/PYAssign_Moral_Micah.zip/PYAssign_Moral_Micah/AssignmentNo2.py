def main():
    grade = float(input('Please enter your percentage achieved in the class: '))
    percent = getPercentage(grade)
   

def getPercentage(grade):    
    try :
        if grade >=93.33 and grade <=100 :
            print("You got A in the class.")
        elif grade < 93.33 and grade >= 90 :
            print("You got A- in the class.")
        elif grade < 90 and grade >=86.67 :
            print("You got B+ in the class.")
        elif grade < 86.67 and grade >=83.33 :
            print("You got B in the class.")
        elif grade < 83.33 and grade >=80 :
            print("You got B- in the class.")
        elif grade < 80 and grade >=76.67 :
            print("You got C+ in the class.")
        elif grade < 76.67 and grade >= 73.33 :
            print("You got C in the class.")
        elif grade < 73.33 and grade >= 70:
            print("You got C- in the class.")
        elif grade < 70 and grade >= 66.67  :
            print("You got D+ in the class.")
        elif grade < 66.67 and grade >= 63.33:
            print("You got D in the class.")
        elif grade < 63.33 and grade >=60 :
            print("You got D- in the class.")
        elif grade < 60 and grade >= 0:
            print("You got F- in the class.")
            
    except ValueError:
        return -1


main()
