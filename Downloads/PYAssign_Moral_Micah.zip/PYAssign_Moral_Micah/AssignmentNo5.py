l = []
def main():
    try:
        inNum = int(input("Please enter an integer less than 50: "))
        setPrime()
        if(isPrime(inNum)):
            print(inNum, "is prime")
        else:
            print(inNum,  "is not prime")
    except ValueError:
        print("Invalid")

def isPrime(n):
    if n in l:
        return True
    return False

def setPrime():
    for i in range(2, 1000):
        isPrime = True
        for j in range(2, i):
            if i % j == 0:
                isPrime = False
                break
        if isPrime:
            l.append(i)
            
if '__main__' == __name__:
    main()
