<html>
<head><link rel="stylesheet" type="text/css" href="css/bootstrap.css"></head>
      <div class='navbar '>
        <div class='navbar-inner' style='background:skyblue'>
          <div class='container'>
            <div class='span12 columns'>
              <div class='row'>
                <div class='span1' style='margin-top:-40px'>
                  <img src="lvcc_logo.png" width='80px';hieght='80px' style='margin-top:60px;margin-bottom:25px'>
                </div>
                <div class='span5' style='margin-top:-40px'>
                  <label style='margin-top:80px;margin-left:-15px'><font size='5' face='tolkien'>La Verdad Christian College</font></label></div>
              </div>
          </div>
        </div>
      </div>
<body>
	<div class='columns'>
	<div class='container'>
	<div class='span12'>
			<div class='span5 well' style='margin-top:20px'>
				<img src="La Verdad.jpg" style='width:500px;height:250px'>
			</div>
			<div class='span5 well' style='margin-top:20px'>
				<b>Username : </b><input type='text' name='username' style='width:250px;height:30px' placeholder='email Address'><br>
				<b>Password: </b> <input type='password' name='password'style='width:250px;height:30px'><br>
				<a href="#"  style='margin-left:250px'><button class='btn btn'>Sign in </button></a><br>
				Forgot Password?<a href="#">Click here.</a>
			</div>
		</div>
		</div>
		</div>
</body>
</html>