<html>
	<head><link rel="stylesheet" type="text/css" href="css/bootstrap.css"></head>
	<body>
    <!-- header.. -->
      <div class='navbar '>
        <div class='navbar-inner' style='background:skyblue'>
          <div class='container'>
            <div class='span12 columns'>
              <div class='row'>
                <div class='span1' style='margin-top:-40px'>
                  <img src="lvcc_logo.png" width='80px';hieght='80px' style='margin-top:60px;margin-bottom:25px'>
                </div>
                <div class='span5' style='margin-top:-40px'>
                  <label style='margin-top:80px;margin-left:-15px'><font size='5' face='tolkien'>La Verdad Christian College</font></label></div>
              </div>
          </div>
        </div>
      </div>
      <!-- navigation.. -->
       <div class='row'>
                <ul class='nav pull-right'>
                   <li class='dropdown'>
                    <a href="Notes.php"  class='dropdown-toggle' data-toggle='dropdown'>
                      <b>Notes</b>
                    </a>
                  </li>
                  <li class='dropdown'>
                    <a href="Schedule.php"  class='dropdown-toggle' data-toggle='dropdown'>
                      <b>Schedule</b>
                    </a>
                  </li>
                   <li class='dropdown'>
                    <a href="#"  class='dropdown-toggle' data-toggle='dropdown'>
                      <b>Grades</b>
                    </a>
                  </li> <li class='dropdown'>
                    <a href="#"  class='dropdown-toggle' data-toggle='dropdown'>
                      <b>Virtual Classroom</b>
                    </a>
                  </li> <li class='dropdown'>
                    <a href="#"  class='dropdown-toggle' data-toggle='dropdown'>
                      <b>elibrary</b>
                    </a>
                  </li>
                   <li class='dropdown'>
                    <a href="#"  class='dropdown-toggle' data-toggle='dropdown'>
                      <img src="Me.jpg" style='width:40px;height:40px'>
                      <ul class='dropdown-menu'>
                          <li><a href="#">Settings</a></li>
                          <li><a href="#">Profile</a></li>
                          <li><a href="#">SignOut</a></li>
                      </ul>
                   </li>
                    </a>
                </ul>
              </div>
            </div>				
  </body>
	<script type='text/javascript' src = 'javascript/jquery.js'></script>
	<script type='text/javascript' src = 'javascript/bootstrap.min.js'></script>
	</body>
</html>