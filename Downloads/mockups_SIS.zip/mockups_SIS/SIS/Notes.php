<html>
<head><link rel="stylesheet" type="text/css" href="css/bootstrap.css"></head>
<?php
include_once("navigation.php");
?>
<body>
	<!-- notes start here -->
	<div class='span12 columns' style='margin-top:-5px'>
		<!-- body of notes -->
		<div class='row'  style='margin-left:50px'>
			<div class='span10 well'>
				<table class='table table-hover table-striped table-bordered'>
					<tr>
						<thead>
 							   <th class="header"><center>Notes</center></th>
 							   <th class="blue header">Date POsted</th>
 						    <th class="green header">Mark</th>
						</thead>
					</tr>
					<tbody>
						<tr>  
							<td>Please be informed that you need to get a removal exam in Statistics because your grade is lower that 2.5  </td>
							<td>12-02-2013</td>
							<td>Read</td>
						</tr>
						<tr>  
							<td>Please be informed that you need to get a removal exam in Statistics because your grade is lower that 2.5  </td>
							<td>12-02-2013</td>
							<td>Read</td>
						</tr>
						<tr>  
							<td>Please be informed that you need to get a removal exam in Statistics because your grade is lower that 2.5  </td>
							<td>12-02-2013</td>
							<td>Read</td>
						</tr>
					</tbody>
				</table>

			</div>
		</div>
	</div>

</body>
</html>