
<?php
require_once('config.php');
?>

<html>
	<body>
			<center>
		<h1>Messages</h1>
		
<table border = '1'>
		<tr>
			<th>Name</th>
			<th>Email</th>
			<th>Message</th>
			<th>Date Approved</th>
		</tr>
</table><br><br>


		<h1>Post New Message</h1>

		<form action = "postmessage.php" method = "post" >

		Name:<input type = "text" name = "name"><br><br>
		Email:<input type = "text" name = "email"><br><br>
		Message:<br><br>
		<textarea name = "message"></textarea><br><br>
		<input type = "submit" value = "Post Message">
		<input type = "submit" value = "View Messages">
		

	</body>
</form>																																																																																																																																																						
</center>
</html>			
